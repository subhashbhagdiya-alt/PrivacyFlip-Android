package com.privacyflip.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Calendar
import java.util.Locale

/** Handles the small set of system events currently supported by the MVP. */
object AutomationEventProcessor {
    private const val PREFS = "privacy_flip_local"
    private const val LOG_KEY = "eventLog"
    private const val CHANNEL_ID = "privacy_flip_events"

    fun handle(context: Context, event: String, onlyRuleId: String? = null) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean("masterPaused", false)) return

        val rules = try {
            JSONArray(prefs.getString("customRules", "[]"))
        } catch (_: Exception) {
            JSONArray()
        }

        for (index in 0 until rules.length()) {
            val rule = rules.optJSONObject(index) ?: continue
            if (!rule.optBoolean("enabled", false)) continue
            if (onlyRuleId != null && rule.optString("id") != onlyRuleId) continue
            if (rule.optString("trigger") != event) continue
            if (event == "Time schedule") {
                val now = Date()
                val currentTime = SimpleDateFormat("HH:mm", Locale.US).format(now)
                val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now)
                val scheduledTime = rule.optString("scheduledTime", "09:00")
                val lastRunDate = prefs.getString("lastScheduleRun_${rule.optString("id")}", "") ?: ""
                if (scheduledTime > currentTime || lastRunDate == today) continue
                prefs.edit().putString("lastScheduleRun_${rule.optString("id")}", today).apply()
            }

            val name = rule.optString("name", "Custom rule").ifBlank { "Custom rule" }
            when (rule.optString("action")) {
                "Show in-app status", "Write local activity log" -> appendLog(context, "$event — $name")
                "Show notification (permission needed)" -> {
                    appendLog(context, "$event — $name (notification requested)")
                    showNotification(context, name, event)
                }
                // Platform-restricted actions intentionally remain inert until implemented
                // with explicit platform capability checks and device testing.
                else -> appendLog(context, "$event — $name (action not supported yet)")
            }
        }
    }

    private fun appendLog(context: Context, message: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = try { JSONArray(prefs.getString(LOG_KEY, "[]")) } catch (_: Exception) { JSONArray() }
        val entries = mutableListOf<String>()
        for (i in 0 until old.length()) old.optString(i).takeIf { it.isNotBlank() }?.let(entries::add)
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        entries.add("$timestamp · $message")
        val updated = JSONArray()
        entries.takeLast(50).forEach { entry -> updated.put(entry) }
        prefs.edit().putString(LOG_KEY, updated.toString()).apply()
    }

    @Suppress("DEPRECATION")
    private fun showNotification(context: Context, title: String, event: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            appendLog(context, "Notification skipped: permission not granted")
            return
        }
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Privacy Flip automation", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, CHANNEL_ID)
        } else {
            Notification.Builder(context)
        }
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText("Triggered by: $event")
            .setAutoCancel(true)
            .build()
        try {
            manager.notify((title + event).hashCode(), notification)
        } catch (_: SecurityException) {
            appendLog(context, "Notification blocked by system permission")
        }
    }
}

class PowerEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_POWER_CONNECTED -> AutomationEventProcessor.handle(context, "Charger connected")
            Intent.ACTION_POWER_DISCONNECTED -> AutomationEventProcessor.handle(context, "Charger disconnected")
        }
    }
}

class StartupEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED -> AutomationEventProcessor.handle(context, "Device starts")
            Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> Unit
        }
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_TIME_CHANGED || intent.action == Intent.ACTION_TIMEZONE_CHANGED) {
            AutomationScheduler.scheduleNext(context)
        }
    }
}

/** Schedules the next enabled daily rule using an inexact alarm to avoid special exact-alarm access. */
object AutomationScheduler {
    private const val PREFS = "privacy_flip_local"
    private const val REQUEST_CODE = 7104

    fun scheduleNext(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, ScheduleAlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
        if (prefs.getBoolean("masterPaused", false)) return

        val rules = try { JSONArray(prefs.getString("customRules", "[]")) } catch (_: Exception) { JSONArray() }
        val now = Calendar.getInstance()
        val nowTime = SimpleDateFormat("HH:mm", Locale.US).format(now.time)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now.time)
        var nextAt: Calendar? = null
        for (i in 0 until rules.length()) {
            val rule = rules.optJSONObject(i) ?: continue
            if (!rule.optBoolean("enabled", false) || rule.optString("trigger") != "Time schedule") continue
            val time = rule.optString("scheduledTime", "09:00")
            if (!time.matches(Regex("([01]\\d|2[0-3]):[0-5]\\d"))) continue
            val lastRun = prefs.getString("lastScheduleRun_${rule.optString("id")}", "") ?: ""
            val candidate = Calendar.getInstance().apply {
                val parts = time.split(":")
                set(Calendar.HOUR_OF_DAY, parts[0].toInt())
                set(Calendar.MINUTE, parts[1].toInt())
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (time <= nowTime || lastRun == today) add(Calendar.DAY_OF_YEAR, 1)
            }
            if (nextAt == null || candidate.before(nextAt)) nextAt = candidate
        }
        nextAt?.let { calendar ->
            val triggerAt = maxOf(calendar.timeInMillis, System.currentTimeMillis() + 60_000L)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            } else {
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            }
        }
    }
}

class ScheduleAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AutomationEventProcessor.handle(context, "Time schedule")
        AutomationScheduler.scheduleNext(context)
    }
}
