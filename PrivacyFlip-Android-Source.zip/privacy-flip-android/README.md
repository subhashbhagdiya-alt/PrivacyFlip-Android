# Privacy Flip — Native Android MVP source

This is the first native Android project scaffold for Privacy Flip.

## Current scope
- Kotlin + Jetpack Compose
- Minimum SDK Android 8.0 (API 26)
- Offline local preferences
- Dashboard, preset library (54 starter/demo entries), rule list, diagnostics and settings screens
- Per-preset and per-action ON/OFF controls
- Light/dark theme preference
- Hindi/English UI labels for core navigation

## Important status
This is a source-code starter, not a verified APK. The current MVP persists user toggles locally and includes manual JSON export/import; it does **not yet execute system-level automations**. Android Auto Backup is disabled in the manifest to match the offline-first intent. Android restrictions mean each real trigger/action must be implemented and tested separately. Do not describe Wi-Fi/Bluetooth/system toggles as working until device tests prove it.

## Build
Run `python3 tools/verify_source.py` for offline structural checks. These checks are not an Android compile. Then open this folder in Android Studio (Giraffe or newer), allow Gradle sync, and choose **Build > Build APK(s)**.
Expected debug APK path: `app/build/outputs/apk/debug/app-debug.apk`.

A GitHub Actions workflow is included to build a debug APK when this project is pushed into a GitHub repository. This archive itself is not connected to a repository or CI run.

## Technical baseline
- Gradle Android plugin 8.7.3
- Kotlin 2.0.21
- Compose BOM 2024.09.00
- compileSdk 35, targetSdk 35, minSdk 26

## Latest source update
- Added a local custom IF–THEN rule builder with selectable trigger/action, daily `HH:mm` time for schedule rules, enable/disable toggle, deletion, and JSON backup/restore support for custom rules.
- Added manifest receivers for charger connect/disconnect and device boot broadcasts.
- Matching enabled custom rules are processed for charger connected/disconnected and device boot events, unless Master Pause is on. The event processor writes a bounded local activity log and can show a local Android notification when that action is selected and permission is granted. The processor and manifest receivers are present in source; real-device delivery and notification behavior still require testing.
- Battery threshold rules are checked while the app UI is open, using a configurable 5–50% threshold (default 20%). The threshold is included in JSON backup/restore. Continuous background battery monitoring is not implemented.
- Screen ON/OFF events are dynamically observed while the app process is alive and passed to matching custom rules. Android does not support these as ordinary manifest receivers, so this does not guarantee delivery after the app process is killed.
- Daily schedule rules now accept a 24-hour `HH:mm` time and use `AlarmManager.setAndAllowWhileIdle` (inexact) to trigger the supported local-log or notification actions. Android may delay alarms under Doze/battery restrictions. The scheduler re-arms after boot, system time/time-zone changes, app launch, rule edits, rule toggles, backup restore, and Master Pause changes. Exact timing is not guaranteed.
- Schedule execution is once per local calendar day per rule; time changes and daylight-saving transitions still need real-device testing.
- Network changes are observed through `ConnectivityManager.registerDefaultNetworkCallback` while the app composition/process is alive. The callback tracks the default network to suppress the initial network snapshot and avoid duplicate events during handoffs. This is not a guaranteed background trigger after process death. Face-down flip is observed through the accelerometer while the app process/composition is alive; this is not a background sensor service. A manual rule has a per-rule Run now action. Wi-Fi/Bluetooth/sound actions are deliberately not executed yet.
- Added `ACCESS_NETWORK_STATE` and a dynamically registered default-network callback. The initial active-network snapshot is intended to be ignored while later availability/loss events feed enabled custom rules. Accelerometer support is optional at install time; face-down threshold detection is foreground/process-lifetime only.
- Custom-rule dropdowns now disable unsupported actions instead of allowing users to save rules that pretend to switch protected Wi-Fi/Bluetooth/sound settings. Backup import skips unsupported trigger/action combinations. The event processor can run a specific manual rule without also running every other manual rule. A previously found missing `Context` in the Home page was fixed and added to structural verification.
- Android SDK/Gradle was not available in the current working environment and outbound DNS could not resolve the Android SDK host, so compilation and device tests have not yet been run. Network callback ordering, schedule delivery, notification permission, battery threshold behavior, reboot rescheduling, and screen/charging event behavior still require real-device verification.

## Version 0.1.1 changes
- Fixed a missing `Context` in the Home screen that blocked compilation.
- Added foreground face-down flip detection via the optional accelerometer and a per-rule **Run now** control for manual quick-action rules.
- Disabled unsupported actions in the rule builder and reject them during backup import, so protected Wi-Fi/Bluetooth/sound controls are not presented as functional.
- Added `tools/build_debug_apk.sh` to run the source checks, invoke Gradle, and confirm that the expected debug APK exists.

## Build requirements
- JDK 17
- Gradle 8.9 (or the repository's Gradle wrapper, if one is added)
- Android SDK platform 35 and build-tools 35.0.0

From the project root, run `./tools/build_debug_apk.sh`. The script fails early with a direct message when the Android SDK or Gradle is not configured. The included GitHub Actions workflow also builds `assembleDebug` and uploads the APK artifact once the source folder is committed to a GitHub repository; the workflow has not run in this workspace.
