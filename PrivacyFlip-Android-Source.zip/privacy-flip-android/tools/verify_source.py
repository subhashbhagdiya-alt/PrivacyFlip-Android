#!/usr/bin/env python3
"""Fast, offline structural checks for Privacy Flip. Not a replacement for Android compilation/device tests."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"
APP_BUILD = ROOT / "app/build.gradle.kts"
MAIN = ROOT / "app/src/main/java/com/privacyflip/app/MainActivity.kt"
EVENTS = ROOT / "app/src/main/java/com/privacyflip/app/AutomationReceivers.kt"
WORKFLOW = ROOT / ".github/workflows/android-apk.yml"
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"
errors: list[str] = []


def require(condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)

for path in (MANIFEST, APP_BUILD, MAIN, EVENTS, WORKFLOW):
    require(path.is_file(), f"Required project file is missing: {path.relative_to(ROOT)}")

if not errors:
    manifest = ET.parse(MANIFEST).getroot()
    permissions = {node.attrib.get(ANDROID_NS + "name", "") for node in manifest.findall("uses-permission")}
    require("android.permission.ACCESS_NETWORK_STATE" in permissions, "ACCESS_NETWORK_STATE permission missing")
    require("android.permission.RECEIVE_BOOT_COMPLETED" in permissions, "RECEIVE_BOOT_COMPLETED permission missing")
    require("android.permission.POST_NOTIFICATIONS" in permissions, "POST_NOTIFICATIONS permission missing")
    require("android.permission.INTERNET" not in permissions, "Unexpected INTERNET permission: MVP is documented as offline-first")
    require(manifest.find("application").attrib.get(ANDROID_NS + "allowBackup") == "false", "Android Auto Backup must remain disabled")

    receiver_names = {r.attrib.get(ANDROID_NS + "name", "") for r in manifest.findall("application/receiver")}
    for receiver in (".PowerEventReceiver", ".StartupEventReceiver", ".ScheduleAlarmReceiver"):
        require(receiver in receiver_names, f"Manifest receiver missing: {receiver}")

    main = MAIN.read_text(encoding="utf-8")
    events = EVENTS.read_text(encoding="utf-8")
    app_build = APP_BUILD.read_text(encoding="utf-8")
    workflow = WORKFLOW.read_text(encoding="utf-8")

    for trigger in ("Screen turns off", "Screen turns on", "Device starts", "Time schedule", "Charger connected", "Charger disconnected", "Battery threshold", "Network changes"):
        require(trigger in main or trigger in events, f"Expected trigger not wired in source: {trigger}")
    for source_marker in (
        "ConnectivityManager.NetworkCallback()",
        "SensorManager.SENSOR_DELAY_NORMAL",
        "AutomationEventProcessor.handle(context, \"Motion / flip\")",
        "supportedCustomTriggers",
        "supportedCustomActions",
        "registerDefaultNetworkCallback(networkCallback)",
        "unregisterNetworkCallback(networkCallback)",
        "Intent.ACTION_SCREEN_OFF",
        "Intent.ACTION_SCREEN_ON",
        "AutomationScheduler.scheduleNext",
        "CreateDocument(\"application/json\")",
        "OpenDocument()",
    ):
        require(source_marker in main, f"MainActivity source marker missing: {source_marker}")
    for source_marker in (
        "class PowerEventReceiver",
        "class StartupEventReceiver",
        "class ScheduleAlarmReceiver",
        "object AutomationEventProcessor",
        "setAndAllowWhileIdle",
        "if (prefs.getBoolean(\"masterPaused\", false)) return",
        "Show notification (permission needed)",
    ):
        require(source_marker in events, f"Automation source marker missing: {source_marker}")
    for version in ('compileSdk = 35', 'targetSdk = 35', 'minSdk = 26', 'versionName = "0.1.1"'):
        require(version in app_build, f"Android build configuration missing: {version}")
    # Catch a previously observed scope bug: HomePage schedules alarms, so it needs a Context.
    home_page = main.split("private fun HomePage", 1)[1].split("@Composable", 1)[0] if "private fun HomePage" in main else ""
    require("val context = LocalContext.current" in home_page, "HomePage must obtain Context before scheduling automation alarms")
    require('"Manual quick action"' in main and 'Text("Run now")' in main, "Manual quick action needs a visible Run now control")
    require('onlyRuleId: String? = null' in events and 'rule.optString("id") != onlyRuleId' in events, "Manual execution must be scoped to the selected rule")
    require("gradle-version: '8.9'" in workflow, "CI should use the Gradle version compatible with AGP 8.7.3")
    require("python3 tools/verify_source.py" in workflow, "CI source-integrity step missing")
    require("gradle assembleDebug" in workflow, "CI APK build step missing")

if errors:
    print("Privacy Flip source checks FAILED:")
    for error in errors:
        print(f"  - {error}")
    sys.exit(1)

print("Privacy Flip source checks passed.")
print("Note: these structural checks do not compile Kotlin or replace Android device tests.")
