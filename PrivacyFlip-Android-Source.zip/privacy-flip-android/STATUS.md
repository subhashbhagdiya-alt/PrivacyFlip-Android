# Privacy Flip — build and completion status

Status date: 2026-10-28
Source version: 0.1.1

## Current milestone: native Android MVP source

### Present in source
- Kotlin + Jetpack Compose application scaffold and offline local settings.
- Preset library UI and custom IF–THEN rule builder with local save/enable/delete.
- JSON export/import through Android's file picker.
- Master Pause gate in the event processor.
- Event handlers for charger connect/disconnect, boot, screen on/off while the app composition/process is alive, daily inexact alarms, foreground battery-threshold observation, default-network changes while the app composition/process is alive, and foreground face-down flip detection via accelerometer.
- Local activity log and permission-aware notification action.
- Restricted Wi-Fi/Bluetooth/sound actions are disabled in the rule builder and remain inert rather than pretending the app can change protected system settings. Manual rules have a per-rule Run now button.
- Offline source-integrity checker (`python3 tools/verify_source.py`) and a GitHub Actions workflow that is intended to build a debug APK.

### Verified in this workspace
- `python3 tools/verify_source.py` passes and now catches the known Home-page `Context` scope regression, unsupported action exposure, and manual-rule scoping markers.
- Android manifest XML parses and the source ZIP passes `unzip -t`.
- Basic Kotlin parse scan after fixes has no parser-style `expecting` / `unexpected tokens` diagnostic, but unresolved Android/Compose references make this only a parse smoke check, not a successful Android compile. An actual missing `Context` in HomePage was fixed.

### Not verified / blockers
- No Android SDK, Gradle installation, or Android build-tools are available in the current workspace. Outbound DNS resolution for `dl.google.com` also failed, preventing SDK installation here.
- This project is not connected to a dedicated GitHub repository, so the included CI workflow has not run.
- No debug APK has been generated here. `tools/build_debug_apk.sh` was added, but execution stops at the SDK preflight in this workspace because Android SDK/Gradle are absent.
- No real-device tests have been run. Trigger delivery, notification permission, reboot recovery, scheduled alarms, network callback ordering, and battery/screen/charging behavior need Android-device validation.

## MVP completion checklist

Treat the first MVP as complete only after all three gates pass:
1. **Build gate:** Android Gradle build completes and creates `app/build/outputs/apk/debug/app-debug.apk`.
2. **Device gate:** Install the APK and verify Master Pause, local rules, charger/boot events, screen/network foreground-process events, daily schedule, battery threshold behavior, notification permission, and JSON backup/restore on an Android phone.
3. **Release gate:** Fix any compile/runtime issues, document Android-version limits, and provide the tested APK plus source.

No calendar completion date is set because the build and device-test gates are not yet available. Advanced features such as reliable background monitoring after process death, geofencing, app-open/close triggers, and direct Wi-Fi/Bluetooth control are outside this first verified MVP and need separate platform-specific implementation. Face-down flip detection is now implemented only while the app process/composition is active; it has not been device-tested.
